from django.conf.urls import url
from publisher import views

urlpatterns = [
    url(r'^publisher_list/$',views.publisher_list),
    url(r'^publisher/add/$',views.publisher_add),
    url(r'^publisher_del/(?P<pk>\d+)/$',views.publisher_del),
    url(r'^publisher_edit/(?P<pk>\d+)/$',views.publisher_edit), # 开头的"/"只有在根下的urls.py里默认添加，如果在第二层就不会自动加'/'了
]
